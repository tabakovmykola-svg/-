package com.myhome.aura

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

class AuraVoiceService : Service(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var recognizerIntent: Intent
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var isSpeaking = false
    private var isActiveDialog = false

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val httpClient = OkHttpClient()

    override fun onCreate() {
        super.onCreate()
        acquireWakeLock()
        startForegroundServiceWithNotification()
        initTTS()
        initSpeechRecognizer()
        startListening()
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AuraSmartHome::VoiceWakeLock")
        wakeLock?.acquire(24 * 60 * 60 * 1000L)
    }

    private fun startForegroundServiceWithNotification() {
        val channelId = "aura_voice_channel"
        val channel = NotificationChannel(
            channelId,
            "АУРА Фоновый Ассистент",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("АУРА на связи")
            .setContentText("Фоновое прослушивание активно. Скажите «Аура».")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    private fun broadcastState(state: String, text: String = "", actionJson: String = "") {
        val intent = Intent("com.myhome.aura.STATE_UPDATE").apply {
            putExtra("state", state)
            putExtra("text", text)
            putExtra("actionJson", actionJson)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun initTTS() {
        tts = TextToSpeech(this, this)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
                broadcastState("speaking")
                CoroutineScope(Dispatchers.Main).launch { speechRecognizer?.stopListening() }
            }

            override fun onDone(utteranceId: String?) {
                isSpeaking = false
                broadcastState("idle")
                CoroutineScope(Dispatchers.Main).launch { startListening() }
            }

            override fun onError(utteranceId: String?) {
                isSpeaking = false
                broadcastState("idle")
                CoroutineScope(Dispatchers.Main).launch { startListening() }
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ru", "RU")
            tts?.setPitch(1.05f)
            tts?.setSpeechRate(1.05f)
        }
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heardText = matches?.firstOrNull()?.lowercase(Locale.getDefault()) ?: ""

                if (heardText.isNotEmpty()) {
                    processVoiceInput(heardText)
                } else {
                    restartListeningWithDelay()
                }
            }

            override fun onError(error: Int) {
                if (!isSpeaking) {
                    restartListeningWithDelay()
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (!isSpeaking) {
            try {
                speechRecognizer?.startListening(recognizerIntent)
            } catch (e: Exception) {
                restartListeningWithDelay()
            }
        }
    }

    private fun restartListeningWithDelay() {
        CoroutineScope(Dispatchers.Main).launch {
            delay(250)
            startListening()
        }
    }

    private fun processVoiceInput(text: String) {
        val wakeWords = listOf("аура", "авра", "ауро", "aura")
        val hasWakeWord = wakeWords.any { text.contains(it) }

        if (hasWakeWord || isActiveDialog) {
            broadcastState("listening", text)
            var cleanCommand = text
            wakeWords.forEach { cleanCommand = cleanCommand.replace(it, "").trim() }

            if (cleanCommand.isEmpty()) {
                isActiveDialog = true
                speak("Да, слушаю тебя. Что сделать?")
                return
            }

            isActiveDialog = false
            broadcastState("thinking", cleanCommand)
            askGeminiAndExecute(cleanCommand)
        } else {
            startListening()
        }
    }

    private fun askGeminiAndExecute(userCommand: String) {
        val prefs = getSharedPreferences("AuraPrefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("gemini_key", "") ?: ""
        val webhookUrl = prefs.getString("webhook_url", "") ?: ""

        if (apiKey.isBlank()) {
            val localResult = handleLocalFallback(userCommand)
            broadcastState("action", localResult.optString("reply"), localResult.toString())
            if (webhookUrl.isNotBlank()) sendToSmartHomeServer(webhookUrl, localResult)
            speak(localResult.optString("reply"))
            return
        }

        serviceScope.launch {
            try {
                val prompt = """
                    Ты голосовой ИИ-ассистент умного дома АУРА. Отвечай живо, дружелюбно и кратко (1-2 предложения).
                    Всегда возвращай JSON формата:
                    {"reply": "Текст ответа голосом", "action": "light_on|light_off|climate|coffee|scene_movie|scene_night|status|none", "target": "living|kitchen|bedroom|all", "value": "число или пусто"}
                    Команда пользователя: "$userCommand"
                """.trimIndent()

                val jsonBody = JSONObject().apply {
                    put("contents", JSONArray().put(JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    }))
                    put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
                }

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                    .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                val bodyStr = response.body?.string() ?: ""
                val resultText = JSONObject(bodyStr)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(resultText)
                val reply = parsed.optString("reply", "Выполняю.")
                val action = parsed.optString("action", "none")

                if (action != "none" && webhookUrl.isNotBlank()) {
                    sendToSmartHomeServer(webhookUrl, parsed)
                }

                withContext(Dispatchers.Main) {
                    broadcastState("action", reply, parsed.toString())
                    speak(reply)
                }
            } catch (e: Exception) {
                val fallback = handleLocalFallback(userCommand)
                withContext(Dispatchers.Main) {
                    broadcastState("action", fallback.optString("reply"), fallback.toString())
                    speak(fallback.optString("reply"))
                }
            }
        }
    }

    private fun handleLocalFallback(cmd: String): JSONObject {
        val obj = JSONObject()
        when {
            cmd.contains("свет") && (cmd.contains("включ") || cmd.contains("зажг")) -> {
                obj.put("reply", "Включаю освещение в доме.")
                obj.put("action", "light_on")
                obj.put("target", "all")
            }
            cmd.contains("свет") && (cmd.contains("выключ") || cmd.contains("погас")) -> {
                obj.put("reply", "Выключаю свет.")
                obj.put("action", "light_off")
                obj.put("target", "all")
            }
            cmd.contains("кино") -> {
                obj.put("reply", "Активирую режим кинотеатра. Приглушаю свет.")
                obj.put("action", "scene_movie")
            }
            cmd.contains("кофе") -> {
                obj.put("reply", "Запускаю кофемашину на кухне.")
                obj.put("action", "coffee")
            }
            cmd.contains("ночь") || cmd.contains("спать") -> {
                obj.put("reply", "Перевожу дом в ночной режим. Спокойной ночи!")
                obj.put("action", "scene_night")
            }
            else -> {
                obj.put("reply", "Поняла команду: $cmd. Укажите API-ключ Gemini в настройках для полного интеллекта.")
                obj.put("action", "none")
            }
        }
        return obj
    }

    private fun sendToSmartHomeServer(url: String, commandJson: JSONObject) {
        try {
            val req = Request.Builder()
                .url(url)
                .post(commandJson.toString().toRequestBody("application/json".toMediaType()))
                .build()
            httpClient.newCall(req).execute().close()
        } catch (_: Exception) {}
    }

    private fun speak(text: String) {
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "AURA_REPLY")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeLock?.release()
        speechRecognizer?.destroy()
        tts?.shutdown()
        serviceScope.cancel()
        super.onDestroy()
    }
}
