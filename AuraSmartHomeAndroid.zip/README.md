# АУРА — Автоматическая сборка APK через GitHub Actions

1. Создайте новый пустой репозиторий на github.com.
2. Нажмите "uploading an existing file" и загрузите ВСЕ файлы и папки изнутри папки `AuraSmartHomeAndroid` (включая скрытую папку `.github`).
3. Перейдите во вкладку **Actions** в репозитории, дождитесь зеленой галочки (~2 минуты) и скачайте готовый APK из раздела **Artifacts -> AuraSmartHome-APK**.
